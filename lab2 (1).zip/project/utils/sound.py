#!/usr/bin/env python3

from typing import Tuple
import simpleaudio as sa
import math

BASE_SOUND = lambda x, freq : math.sin(2 * math.pi * freq * x)


def gen_freq(frequency=440, seconds=1, vol_factor=0.2, fs=8000):
    "Generate a byte-string of a sin-wave based sound, given a frequency, time, and volume."
    return gen_custom_freq(frequency, seconds, vol_factor, fs)


def gen_custom_freq(frequency=440, seconds=1, vol_factor=0.2, fs=8000, func=None):
    """
    Generate a byte-string of a sin-wave based sound, given a frequency, time, and volume.
    func is a function with two inputs, x for time, and frequency for what the frequency is.
    """
    if func is None:
        func = BASE_SOUND

    t = [i/fs for i in range(0, int(seconds * fs))]
    note = [func(i, frequency) for i in t]
    maximum = max([abs(i) for i in note ])
    audio = [int(i * vol_factor * (2**15 - 1)) / maximum for i in note]
    audio = b"".join([int(i).to_bytes(2,"little",signed=True) for i in audio])
    return audio


def play_freq(frequency=440, seconds=1, vol_factor=0.2, fs=8000, bg_play=False):
    "Play a sound given frequency, time, and volume."
    audio = gen_freq(frequency, seconds, vol_factor, fs)
    play_obj = sa.play_buffer(audio, 1, 2, fs)
    return play_obj if bg_play else play_obj.wait_done()


def play_many_freq(frequencies: list[Tuple[int, float, float]], fs=8000, bg_play=False):
    """
    Play many frequencies. Accepts a list of 3-length tuplets, each consisting of (freq, sec, vol).
    freq is in Hz or Hertz
    sec uses seconds
    vol is a scale from 0 to 1
    """
    audio = b"".join([gen_freq(f, s, v, fs) for f, s, v in frequencies])
    play_obj = sa.play_buffer(audio, 1, 2, fs)
    return play_obj if bg_play else play_obj.wait_done()


def play_many_notes(notes: list[Tuple[str, float, float]], fs=8000, bg_play=False):
    """
    Play many notes. Accepts a list of 3-length tuplets, each consisting of (note, sec, vol).
    notes such as "A4" or "Bb2"
    sec uses seconds
    vol is a scale from 0 to 1
    """
    audio = b"".join([gen_freq(NOTE[n], s, v, fs) for n, s, v in notes])
    play_obj = sa.play_buffer(audio, 1, 2, fs)
    return play_obj if bg_play else play_obj.wait_done()


def play_note(note_name="A4", seconds=1, vol_factor=0.2, fs=8000, bg_play=False):
    """
    Play a sound given note name, time, and volume.

    Sound will play on its own thread, separate from the main thread.
    Sound will stop when the main thread exits.

    If bg_play (background play) is True, play and return a sound object s, which has the following methods:
    -- s.wait_done(): pauses current thread until sound has stopped playing
    -- s.stop(): stops the sound from playing
    -- s.is_playing(): whether the sound is playing or not
    If bg_play is False, pauses current thread until sound has stopped playing then return None
    
    Note use the format A4, B4, C#2, Gb6...etc.
    Warning: there is no support for B#_, E#_, Cb_, or Fb_

    NOTE: Use play_many_notes() to get one continuous sound object s
    """
    play_obj = play_freq(NOTE[note_name], seconds, vol_factor, fs, bg_play=True)  # True to get the sound object
    return play_obj if bg_play else play_obj.wait_done()


NOTE = {
    "C0": 16.35,
    "D0": 18.35,
    "E0": 20.60,
    "F0": 21.83,
    "G0": 24.50,
    "A0": 27.50,
    "B0": 30.87,
    "C1": 32.70,
    "D1": 36.71,
    "E1": 41.20,
    "F1": 43.65,
    "G1": 49.00,
    "A1": 55.00,
    "B1": 61.74,
    "C2": 65.41,
    "D2": 73.42,
    "E2": 82.41,
    "F2": 87.31,
    "G2": 98.00,
    "A2": 110.00,
    "B2": 123.47,
    "C3": 130.81,
    "D3": 146.83,
    "E3": 164.81,
    "F3": 174.61,
    "G3": 196.00,
    "A3": 220.00,
    "B3": 246.94,
    "C4": 261.63,
    "D4": 293.66,
    "E4": 329.63,
    "F4": 349.23,
    "G4": 392.00,
    "A4": 440.00,
    "B4": 493.88,
    "C5": 523.25,
    "D5": 587.33,
    "E5": 659.25,
    "F5": 698.46,
    "G5": 783.99,
    "A5": 880.00,
    "B5": 987.77,
    "C6": 1046.50,
    "D6": 1174.66,
    "E6": 1318.51,
    "F6": 1396.91,
    "G6": 1567.98,
    "A6": 1760.00,
    "B6": 1975.53,
    "C7": 2093.00,
    "D7": 2349.32,
    "E7": 2637.02,
    "F7": 2793.83,
    "G7": 3135.96,
    "A7": 3520.00,
    "B7": 3951.07,
    "C8": 4186.01,
    "D8": 4698.63,
    "E8": 5274.04,
    "F8": 5587.65,
    "G8": 6271.93,
    "A8": 7040.00,
    "B8": 7902.13,
    "C#0" : 17.32,
    "Db0" : 17.32,
    "D#0" : 19.45,
    "Eb0" : 19.45,
    "F#0" : 23.12,
    "Gb0" : 23.12,
    "G#0" : 25.96,
    "Ab0" : 25.96,
    "A#0" : 29.14,
    "Bb0" : 29.14,
    "C#1" : 34.65,
    "Db1" : 34.65,
    "D#1" : 38.89,
    "Eb1" : 38.89,
    "F#1" : 46.25,
    "Gb1" : 46.25,
    "G#1" : 51.91,
    "Ab1" : 51.91,
    "A#1" : 58.27,
    "Bb1" : 58.27,
    "C#2" : 69.30,
    "Db2" : 69.30,
    "D#2" : 77.78,
    "Eb2" : 77.78,
    "F#2" : 92.50,
    "Gb2" : 92.50,
    "G#2" : 103.83,
    "Ab2" : 103.83,
    "A#2" : 116.54,
    "Bb2" : 116.54,
    "C#3" : 138.59,
    "Db3" : 138.59,
    "D#3" : 155.56,
    "Eb3" : 155.56,
    "F#3" : 185.00,
    "Gb3" : 185.00,
    "G#3" : 207.65,
    "Ab3" : 207.65,
    "A#3" : 233.08,
    "Bb3" : 233.08,
    "C#4" : 277.18,
    "Db4" : 277.18,
    "D#4" : 311.13,
    "Eb4" : 311.13,
    "F#4" : 369.99,
    "Gb4" : 369.99,
    "G#4" : 415.30,
    "Ab4" : 415.30,
    "A#4" : 466.16,
    "Bb4" : 466.16,
    "C#5" : 554.37,
    "Db5" : 554.37,
    "D#5" : 622.25,
    "Eb5" : 622.25,
    "F#5" : 739.99,
    "Gb5" : 739.99,
    "G#5" : 830.61,
    "Ab5" : 830.61,
    "A#5" : 932.33,
    "Bb5" : 932.33,
    "C#6" : 1108.73,
    "Db6" : 1108.73,
    "D#6" : 1244.51,
    "Eb6" : 1244.51,
    "F#6" : 1479.98,
    "Gb6" : 1479.98,
    "G#6" : 1661.22,
    "Ab6" : 1661.22,
    "A#6" : 1864.66,
    "Bb6" : 1864.66,
    "C#7" : 2217.46,
    "Db7" : 2217.46,
    "D#7" : 2489.02,
    "Eb7" : 2489.02,
    "F#7" : 2959.96,
    "Gb7" : 2959.96,
    "G#7" : 3322.44,
    "Ab7" : 3322.44,
    "A#7" : 3729.31,
    "Bb7" : 3729.31,
    "C#8" : 4434.92,
    "Db8" : 4434.92,
    "D#8" : 4978.03,
    "Eb8" : 4978.03,
    "F#8" : 5919.91,
    "Gb8" : 5919.91,
    "G#8" : 6644.88,
    "Ab8" : 6644.88,
    "A#8" : 7458.62,
    "Bb8" : 7458.62,
}


def sound_example():
    "Example of using the sound module."
    play_freq(440)
    play_note("Bb4")
    play_many_notes([("A4", 0.5, 0.2), ("E4", 0.5, 0.2), ("C4", 0.5, 0.2), ("F4", 0.5, 0.2)])
    play_note("A4", seconds=3, bg_play=True)  # play a note in the background
    print("This is printed before the note stops playing. Press Ctrl-C to exit.")
    try:
        while True:
            pass
    except BaseException:
        exit()


if __name__ == "__main__":
    sound_example()
